			<div style="border-top: 1px solid #ddd; text-align: center">
				<p>Placebook is a Databases I project with no terms or copyrights.<p>
			</div>
		</div>
	</body>
</html>