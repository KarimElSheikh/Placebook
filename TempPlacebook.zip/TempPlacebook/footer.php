			<div style="border-top: 1px solid #ddd; text-align: center">
				<strong>Placebook is a Databases I project made with a lot of <span class="pepsi papsi-symbol"></span>.</strong>
			</div>
		</div>
	</body>
</html>