<!DOCTYPE html>
<?php
include "header.php";
?>		
<div class="row well well-lg">
    <div class="col-md-2 subHeaderLabel">Explore</div>
    <div class="col-md-2 subHeaderB"><a href="#" data-toggle="tooltip" data-placement="top" title="Restaurants"><span class="glyphicon glyphicon-cutlery"></span></a></div>
    <div class="col-md-2 subHeaderFa"><a href="#" data-toggle="tooltip" data-placement="top" title="Hotels"><span class="fa fa-building"></span></a></div>
    <div class="col-md-2 subHeaderFa"><a href="#" data-toggle="tooltip" data-placement="top" title="Museums"><span class="fa fa-institution"></span></a></div>
    <div class="col-md-2 subHeaderB"><a href="#" data-toggle="tooltip" data-placement="top" title="Monuments"><span class="glyphicon glyphicon-tower"></span></a></div>
    <div class="col-md-2 subHeaderB"><a href="#" data-toggle="tooltip" data-placement="top" title="Cities"><span class="glyphicon glyphicon-flag"></span></a></div>
</div>
<br>
<div class="row well well-lg">
    <div class="col-md-12 subHeaderLabel">Recommended Places</div>
</div>
<br>
<div class="row well well-lg">
    <div class="col-md-12 subHeaderLabel">Similar Users</div>
</div>
<?php
include "footer.php";
?>